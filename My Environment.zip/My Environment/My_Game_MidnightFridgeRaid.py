import pygame
import numpy as np
import time
import os
import gymnasium as gym

# Constants
GRID_SIZE = 15
CELL_SIZE = 50

# Keyboard movement
UP = pygame.K_UP
DOWN = pygame.K_DOWN
LEFT = pygame.K_LEFT
RIGHT = pygame.K_RIGHT

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE))
pygame.display.set_caption("Midnight Fridge Raid")

# --- Image Loading ---
script_dir = os.path.dirname(os.path.abspath(__file__))

agent_img_path = os.path.join(script_dir, "agent.png")
floor_tile_path = os.path.join(script_dir, "floor_tile.jpg")
obstacle_img_path = os.path.join(script_dir, "obstacle.jpg")
bonus_img_path = os.path.join(script_dir, "snack.png")
hell_img_path = os.path.join(script_dir, "dog.jpg")
slippary_tile_path = os.path.join(script_dir, "slippary_tile.png")
goal_img_path = os.path.join(script_dir, "fridge.png")
bedroom_tile_path = os.path.join(script_dir, "wall.png")
musicstep_path = os.path.join(script_dir, "step.mp3")
musicslip_path = os.path.join(script_dir, "slippary.mp3")
musicpet_path = os.path.join(script_dir, "pet.mp3")
musicbonus_path = os.path.join(script_dir, "bonus.mp3")
musicfridge_path = os.path.join(script_dir, "fridge.mp3")
musicgoal_path = os.path.join(script_dir, "goal.mp3")

def load_image(image_path, size):
    image = pygame.image.load(image_path)
    return pygame.transform.scale(image, size)

agent_img = load_image(agent_img_path, (CELL_SIZE, CELL_SIZE))
floor_tile = load_image(floor_tile_path, (CELL_SIZE, CELL_SIZE))
obstacle_img = load_image(obstacle_img_path, (CELL_SIZE, CELL_SIZE))
bonus_img = load_image(bonus_img_path, (CELL_SIZE, CELL_SIZE))
hell_img = load_image(hell_img_path, (CELL_SIZE, CELL_SIZE))
slippary_tile = load_image(slippary_tile_path, (CELL_SIZE, CELL_SIZE))
goal_img = load_image(goal_img_path, (CELL_SIZE, CELL_SIZE))
bedroom_tile = load_image(bedroom_tile_path, (CELL_SIZE, CELL_SIZE))

# Environment Class
class MidnightFridgeRaidEnv(gym.Env):
    def __init__(self):
        self.grid_size = GRID_SIZE
        self.state = np.zeros((GRID_SIZE, GRID_SIZE), dtype=np.uint8)
        self.has_snack = False
        self.points = 0
        self.done = False
        self.collected_bonus = set()
        self.agent_direction = RIGHT
        self.agent_pos = (GRID_SIZE - 1, 0)
        self.slippary_tiles = [(3, 3), (3, 14), (2, 12), (9, 7), (7, 9), (12,12)]
        self.pet_tiles = [(9, 2), (5, 6), (14, 8), (9, 14)]
        self.fridge_pos = (0, 14)
        self.bonus_tiles = [(0, 0), (7, 2), (12, 5), (0, 8), (0, 11), (14, 13), (10, 14), (8, 9)]
        self.bedroom_tiles = [(14, 0)]
        self._setup_game()

    def _setup_game(self):
        self.state.fill(0)
        self.wall_positions = (
            [(i, 11) for i in range(0, 2)] + [(i, 9) for i in range(5, 7)] + 
             [(i, 3) for i in range(0, 3)] + [(i, 6) for i in range(1, 5)] +
             [(i, 7) for i in range(1, 1)] + [(i, 8) for i in range(1, 3)] +
             [(i, 14) for i in range(5, 7)] + [(i, 5) for i in range(10, 14)] +
             [(i, 9) for i in range(10, 14)] + [(3, i) for i in range(0, 2)] +
             [(1, i) for i in range(6, 8)] + [(3, i) for i in range(8, 15)] +
             [(5, i) for i in range(0, 5)] + [(8, i) for i in range(1, 13)] +
             [(10, i) for i in range(0, 5)] + [(10, i) for i in range(9, 14)] +
             [(i, 11) for i in range(5, 7)] + [(i, 7) for i in range(11, 14)] +
             [(i, 6) for i in range(6, 7)] + [(i, 8) for i in range(5, 7)] +
             [(7, i) for i in range(1, 4)] + [(4, i) for i in range(0, 2)]
        )
        self._redraw_state()

    def _redraw_state(self):
        self.state.fill(0)
        self.state[self.agent_pos[0], self.agent_pos[1]] = 1
        self.state[self.fridge_pos[0], self.fridge_pos[1]] = 2
        for pos in self.slippary_tiles:
            self.state[pos[0], pos[1]] = 3
        for pos in self.wall_positions:
            self.state[pos[1], pos[0]] = 4
        for pos in self.pet_tiles:
            self.state[pos[0], pos[1]] = 5
        for pos in self.bonus_tiles:
            if pos not in self.collected_bonus:
                self.state[pos[0], pos[1]] = 6
        for pos in self.bedroom_tiles:
            self.state[pos[0], pos[1]] = 7

    def reset(self):
        self.agent_pos = (GRID_SIZE - 1, 0)
        self.has_snack = False
        self.points = 0
        self.done = False
        self.collected_bonus.clear()
        self._setup_game()
        return self.get_state()

    def get_state(self):
        return self.state.copy()

    def step(self, action):
        pygame.mixer.music.load(musicstep_path)
        pygame.mixer.music.play(-1)
        if self.done:
            return self.get_state(), 0, self.done, {}

        self.agent_direction = action
        x, y = self.agent_pos
        new_x, new_y = x, y

        if action == UP:
            new_x -= 1
        elif action == DOWN:
            new_x += 1
        elif action == LEFT:
            new_y -= 1
        elif action == RIGHT:
            new_y += 1

        # Stay within grid and not inside walls
        if 0 <= new_x < GRID_SIZE and 0 <= new_y < GRID_SIZE:
            if (new_x, new_y) not in [(pos[1], pos[0]) for pos in self.wall_positions]:
                self.agent_pos = (new_x, new_y)

        reward = 0

        if self.agent_pos in self.slippary_tiles:
            print(f"Stepped on a noisy tile! Restart. Total Points: {self.points}.")
            self.points -= 10
            self.reset()
            pygame.mixer.music.load(musicslip_path)
            pygame.mixer.music.play(1)
            return self.get_state(), -10, False, {}

        if self.agent_pos in self.pet_tiles:
            print(f"Woke the pet! Game over. Total Points: {self.points}")
            self.done = True
            self.points -= 20
            pygame.mixer.music.load(musicpet_path)
            pygame.mixer.music.play(1)
            return self.get_state(), -20, True, {}

        if self.agent_pos in self.bonus_tiles and self.agent_pos not in self.collected_bonus:
            reward += 5
            self.points += 5
            self.collected_bonus.add(self.agent_pos)
            pygame.mixer.music.load(musicbonus_path)
            pygame.mixer.music.play(1)
            print(f"Wow... found bonus snack! Total Points: {self.points}")

        if self.agent_pos == self.fridge_pos and not self.has_snack:
            self.has_snack = True
            reward += 10
            self.points += 10
            pygame.mixer.music.load(musicfridge_path)
            pygame.mixer.music.play(1)
            print(f"Snack collected! Now return to bed. Total Points: {self.points}")

        if self.has_snack and self.agent_pos == (GRID_SIZE - 1, 0):
            print(f"Mission complete! Midnight raid success. Total Points: {self.points}")
            reward += 20
            self.points += 20
            pygame.mixer.music.load(musicgoal_path)
            pygame.mixer.music.play(1)
            self.done = True
            

        self._redraw_state()
        return self.get_state(), reward, self.done, {}

    def render(self):
        screen.fill((0, 0, 0))
        for x in range(GRID_SIZE):
            for y in range(GRID_SIZE):
                screen.blit(floor_tile, (y * CELL_SIZE, x * CELL_SIZE))
                cell_state = self.state[x, y]
                if cell_state == 7:
                   screen.blit(bedroom_tile, (y * CELL_SIZE, x * CELL_SIZE))
                elif cell_state == 2:
                    screen.blit(goal_img, (y * CELL_SIZE, x * CELL_SIZE))
                elif cell_state == 3:
                    screen.blit(slippary_tile, (y * CELL_SIZE, x * CELL_SIZE))
                elif cell_state == 4:
                    screen.blit(obstacle_img, (y * CELL_SIZE, x * CELL_SIZE))
                elif cell_state == 5:
                    screen.blit(hell_img, (y * CELL_SIZE, x * CELL_SIZE))
                elif cell_state == 6:
                    screen.blit(bonus_img, (y * CELL_SIZE, x * CELL_SIZE))
        x, y = self.agent_pos
        if self.agent_direction == UP:
            rotated_agent_image = pygame.transform.rotate(agent_img, -270)
        elif self.agent_direction == DOWN:
            rotated_agent_image = pygame.transform.rotate(agent_img, -90)
        elif self.agent_direction == LEFT:
            rotated_agent_image = pygame.transform.rotate(agent_img, 0)
            rotated_agent_image = pygame.transform.flip(rotated_agent_image, True, False)
        elif self.agent_direction == RIGHT:
            rotated_agent_image = pygame.transform.rotate(agent_img, 0)
        else:
            rotated_agent_image = agent_img
        screen.blit(rotated_agent_image, (y * CELL_SIZE, x * CELL_SIZE))
        pygame.display.flip()

    def close(self):
        pygame.quit()

# -------------------------------
# Main Game Loop
# -------------------------------
if __name__ == "__main__":
    env = MidnightFridgeRaidEnv()
    env.reset()
    running = True
    final_score_printed = False

    while running:
        env.render()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                state, reward, done, info = env.step(event.key)
                if done and not final_score_printed:
                    final_score_printed = True
                    print(f"Final Score: {env.points}")
                    time.sleep(2)
                    running = False

    env.close()
